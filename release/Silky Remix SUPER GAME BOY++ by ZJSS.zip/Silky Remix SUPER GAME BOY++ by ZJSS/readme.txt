Credits

Inspired by the Lilla theme by Evolve.
onionos icon by Hakchi Pixel Art by faustbear.

Main page icons by users from flaticon.com:
https://www.flaticon.com/free-icons/electricity - Electricity icons created by srip - Flaticon
https://www.flaticon.com/free-icons/maze - Maze icons created by Becris - Flaticon
https://www.flaticon.com/free-icons/gridGrid icons created by Kiranshastry - Flaticon
https://www.flaticon.com/free-icons/settings - Settings icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/history - History icons created by joalfa - Flaticon
https://www.flaticon.com/free-icons/nintendo - Nintendo icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/star - Star icons created by Pixel perfect - Flaticon

screen backgrounds 

https://github.com/nithou/minimal-onionOS

Icons 

Hakchi Pixel Art by faustbear

All other icons derived from stock Miyoo Mini icons.

Silky Remix SUPER GAME BOY++ by ZJSS

Mod of Silky Remix SUPER GAME BOY by MLOPEZMAD: a logo wall of every console maker at many sizes,
frosted-glass cards and ribbons, cyberpunk HUD accents in SGB red with neon cyan and yellow, new
pixel-art main-menu tiles and icons for every app, console, RetroArch core and setting, a soft
chiptune tick when the selection moves and a short chime when something opens, and Rajdhani /
Titillium Web fonts (SIL Open Font License, see OFL-*.txt).
The main-menu tile art replaces the flaticon glyphs credited above.

Install (Onion OS on a Miyoo Mini or Mini Plus)
1. Copy the folders in the zip (Themes, .tmp_update, App and Roms) to the root of the SD card and
   merge them. On a Mac, .tmp_update is hidden: press Cmd+Shift+. in Finder to see it.
2. Choose the theme in Apps > Themes, then restart the device.

The live layer (live/sgblive) starts at boot from .tmp_update/startup/sgblive.sh, and only when
this is the active theme:
- the wallpaper logos light up on the main menu in two waves at once, one travelling down the
  screen and one up, each with a shining outline, seen through the frosted-glass cards and ribbons
- the Games tile's handheld shows a screenshot of the last game you closed
- the Apps tile's squares show your most recently opened apps, newest in the middle
It only draws on the main menu and pauses in games and apps. Below 20 % battery it stops, and it
comes back once the battery is at 25 %. Choosing another theme stops it; it starts again at the
next restart with this theme, or when you open SGB Live.
Without that startup file the theme still works as a regular, static theme. Installed from
Onion's theme list or MiniMart it is static too: the zip on GitHub has the startup file
(https://github.com/zakijss/SuperGameBoy/releases/latest).
To turn the live layer off or on again, open SGB Live in Apps. It keeps the setting in
/mnt/SDCARD/.tmp_update/config/.sgbliveOff (off while that file exists). To remove the layer,
delete /mnt/SDCARD/.tmp_update/startup/sgblive.sh.
