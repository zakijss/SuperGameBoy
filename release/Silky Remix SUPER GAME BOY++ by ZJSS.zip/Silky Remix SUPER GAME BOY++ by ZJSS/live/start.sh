#!/bin/sh
# Silky Remix SUPER GAME BOY++ live layer: animated wallpaper, frosted glass, live Games/Apps tiles.
# Started at boot by .tmp_update/startup/sgblive.sh (only while this theme is the active one) and
# by the SGB Live app. It runs a small watcher that checks every 5 seconds and starts or stops
# live/sgblive:
#   off while /mnt/SDCARD/.tmp_update/config/.sgbliveOff exists (SGB Live in Apps toggles it)
#   off below LOW % battery, on again from LOW+5 % or while charging (battery saver)
#   stopped for good, watcher included, once another theme is chosen
# It reads only Onion's battery file /tmp/percBat, never anything else in /tmp.
LOW=20
OFF=/mnt/SDCARD/.tmp_update/config/.sgbliveOff
ACTIVE=/mnt/SDCARD/.tmp_update/config/active_theme
PIDF=/tmp/sgblive_watch.pid
D=$(dirname "$0")
THEME=${D%/live}
B="$D/sgblive"

if [ "$1" != watch ]; then
    P=$(cat "$PIDF" 2>/dev/null)
    [ -n "$P" ] && grep -q start.sh "/proc/$P/cmdline" 2>/dev/null && exit 0
    setsid nohup sh "$0" watch >/dev/null 2>&1 &
    exit 0
fi

echo $$ > "$PIDF"
chmod +x "$B" 2>/dev/null
saver=0
while :; do
    T=$(cat "$ACTIVE" 2>/dev/null)
    if [ "${T%/}" != "$THEME" ]; then
        killall sgblive 2>/dev/null
        rm -f "$PIDF"
        exit 0
    fi
    P=$(cat /tmp/percBat 2>/dev/null)
    case "$P" in ''|*[!0-9]*) P=100 ;; esac   # not written yet; 500 means charging on the Mini
    if [ "$P" -le $LOW ]; then saver=1; elif [ "$P" -ge $((LOW + 5)) ]; then saver=0; fi
    if [ -f "$OFF" ] || [ $saver = 1 ]; then
        pidof sgblive >/dev/null && killall sgblive
    elif ! pidof sgblive >/dev/null; then
        setsid nohup "$B" >/dev/null 2>&1 &
    fi
    sleep 5
done
