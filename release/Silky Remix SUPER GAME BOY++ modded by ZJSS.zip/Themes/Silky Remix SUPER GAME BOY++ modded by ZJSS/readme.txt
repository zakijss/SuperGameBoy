Credits

Inspired by the Lilla theme by Evolve.
onionos icon by Hakchi Pixel Art by faustbear.

Main page icons by users from flaticon.com:
https://www.flaticon.com/free-icons/electricity - Electricity icons created by srip - Flaticon
https://www.flaticon.com/free-icons/maze - Maze icons created by Becris - Flaticon
https://www.flaticon.com/free-icons/gridGrid icons created by Kiranshastry - Flaticon
https://www.flaticon.com/free-icons/settings - Settings icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/history - History icons created by joalfa - Flaticon
https://www.flaticon.com/free-icons/nintendo - Nintendo icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/star - Star icons created by Pixel perfect - Flaticon

screen backgrounds 

https://github.com/nithou/minimal-onionOS

Icons 

Hakchi Pixel Art by faustbear

All other icons derived from stock Miyoo Mini icons.

Silky Remix SUPER GAME BOY++, modded by ZJSS

Mod of Silky Remix SUPER GAME BOY by MLOPEZMAD: a logo wall of every console maker at many sizes,
frosted-glass cards and ribbons, cyberpunk HUD accents in SGB red with neon cyan and yellow, new
pixel-art main-menu tiles and icons for every app, console, RetroArch core and setting, a soft
menu sound, and Rajdhani / Titillium Web fonts (SIL Open Font License, see OFL-*.txt).
The main-menu tile art replaces the flaticon glyphs credited above.

Install (Onion OS on a Miyoo Mini or Mini Plus)
1. Copy both folders in the zip, Themes and .tmp_update, to the root of the SD card and merge them.
   On a Mac, .tmp_update is hidden: press Cmd+Shift+. in Finder to see it.
2. Restart the device, then choose the theme in Apps > Themes.

The live layer (live/sgblive) starts at boot from .tmp_update/startup/sgblive.sh:
- the wallpaper logos light up in turn on the main menu, with a shining outline, seen through
  frosted-glass cards and ribbons
- the Games tile's handheld shows a screenshot of the last game you closed
- the Apps tile's squares show your most recently opened apps, newest in the middle
It only runs while this theme is active and the main menu is on screen, and pauses in games and apps.
Without that startup file the theme still works as a regular, static theme.
To turn the live layer off, delete /mnt/SDCARD/.tmp_update/startup/sgblive.sh.
