#!/bin/sh
# Silky Remix SUPER GAME BOY++ live layer: animated wallpaper, frosted glass, live Games/Apps tiles.
# Onion runs this at boot. The layer idles unless the theme is active. Delete this file to turn it off.
pidof sgblive >/dev/null 2>&1 && exit 0
T=$(cat /mnt/SDCARD/.tmp_update/config/active_theme 2>/dev/null)
for B in "${T%/}/live/sgblive" /mnt/SDCARD/Themes/*/live/sgblive; do
    [ -f "$B" ] || continue
    chmod +x "$B" 2>/dev/null
    setsid nohup "$B" >/dev/null 2>&1 &
    exit 0
done
